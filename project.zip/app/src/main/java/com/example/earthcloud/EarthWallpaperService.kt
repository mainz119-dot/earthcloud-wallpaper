package com.example.earthcloud

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.view.SurfaceHolder
import java.io.File
import kotlin.math.max

class EarthWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = SatelliteEngine()

    inner class SatelliteEngine : Engine() {
        private val handler = Handler(Looper.getMainLooper())
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        private var visible = false
        private var frames: List<File> = emptyList()
        private var bitmaps: List<Bitmap> = emptyList()
        private var frameIndex = 0
        private var lastFrameChange = 0L
        private val frameIntervalMs = 1200L

        private val drawTask = object : Runnable {
            override fun run() {
                drawFrame()
                if (visible) handler.postDelayed(this, 250L)
            }
        }

        override fun onVisibilityChanged(isVisible: Boolean) {
            visible = isVisible
            if (visible) {
                loadFramesIfNeeded()
                handler.removeCallbacks(drawTask)
                handler.post(drawTask)
            } else handler.removeCallbacks(drawTask)
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            super.onSurfaceChanged(holder, format, width, height)
            loadFramesIfNeeded(force = true)
            drawFrame()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            visible = false
            handler.removeCallbacks(drawTask)
            super.onSurfaceDestroyed(holder)
        }

        override fun onDestroy() {
            handler.removeCallbacks(drawTask)
            recycleFrames()
            super.onDestroy()
        }

        private fun loadFramesIfNeeded(force: Boolean = false) {
            val folder = File(filesDir, "cloud_frames")
            val latest = folder.listFiles { f -> f.isFile && f.extension.equals("png", true) }
                ?.sortedBy { it.name } ?: emptyList()
            if (!force && latest.map { it.absolutePath } == frames.map { it.absolutePath }) return
            recycleFrames()
            frames = latest
            bitmaps = latest.mapNotNull { file ->
                try {
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeFile(file.absolutePath, bounds)
                    var sample = 1
                    while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
                    BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply { inSampleSize = sample })
                } catch (_: Exception) { null }
            }
            frameIndex = 0
            lastFrameChange = System.currentTimeMillis()
        }

        private fun recycleFrames() {
            bitmaps.forEach { if (!it.isRecycled) it.recycle() }
            bitmaps = emptyList()
            frames = emptyList()
        }

        private fun drawFrame() {
            val holder = surfaceHolder
            var canvas: Canvas? = null
            try {
                canvas = holder.lockCanvas()
                if (canvas != null) render(canvas)
            } catch (_: Exception) {
            } finally {
                if (canvas != null) holder.unlockCanvasAndPost(canvas)
            }
        }

        private fun render(canvas: Canvas) {
            val w = canvas.width
            val h = canvas.height
            canvas.drawColor(Color.rgb(3, 8, 20))
            if (bitmaps.isEmpty()) {
                paint.color = Color.WHITE
                paint.textSize = 34f
                canvas.drawText("GK2A CLD", 36f, h * 0.45f, paint)
                paint.textSize = 22f
                canvas.drawText("앱에서 CLD PNG 영상을 가져와 주세요", 36f, h * 0.45f + 44f, paint)
                return
            }
            val now = System.currentTimeMillis()
            if (bitmaps.size > 1 && now - lastFrameChange >= frameIntervalMs) {
                frameIndex = (frameIndex + 1) % bitmaps.size
                lastFrameChange = now
            }
            val bitmap = bitmaps[frameIndex]
            val scale = max(w.toFloat() / bitmap.width, h.toFloat() / bitmap.height)
            val dw = bitmap.width * scale
            val dh = bitmap.height * scale
            val left = (w - dw) / 2f
            val top = (h - dh) / 2f
            val dst = Rect(left.toInt(), top.toInt(), (left + dw).toInt(), (top + dh).toInt())
            paint.alpha = 255
            canvas.drawBitmap(bitmap, null, dst, paint)

            // Small, unobtrusive live status overlay.
            paint.color = Color.BLACK
            paint.alpha = 150
            canvas.drawRect(0f, 0f, w.toFloat(), 54f, paint)
            paint.alpha = 255
            paint.color = Color.WHITE
            paint.textSize = 22f
            val label = "GK2A CLD  ${frameIndex + 1}/${bitmaps.size}"
            canvas.drawText(label, 22f, 36f, paint)
        }
    }
}
