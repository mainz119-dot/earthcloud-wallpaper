package com.example.earthcloud

import android.app.Activity
import android.app.WallpaperManager
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {
    private val pickImagesRequest = 4102
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
        }
        val title = TextView(this).apply {
            text = "천리안 2A 구름 라이브 배경화면"
            textSize = 22f
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 24)
        }
        val importButton = Button(this).apply {
            text = "CLD 위성영상 PNG 가져오기"
            setOnClickListener { openImagePicker() }
        }
        val wallpaperButton = Button(this).apply {
            text = "라이브 배경화면 설정"
            setOnClickListener {
                try {
                    startActivity(Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                        putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                            android.content.ComponentName(this@MainActivity, EarthWallpaperService::class.java))
                    })
                } catch (_: Exception) {
                    startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
                }
            }
        }
        val note = TextView(this).apply {
            text = "기상청에서 받은 CLD PNG 파일을 여러 장 선택하면 촬영 시각 순서로 재생합니다. 2분 간격 영상 여러 장을 가져오면 구름 이동을 확인할 수 있습니다."
            textSize = 14f
            setPadding(4, 24, 4, 0)
        }
        root.addView(title)
        root.addView(status)
        root.addView(importButton)
        root.addView(wallpaperButton)
        root.addView(note)
        setContentView(root)
        refreshStatus()
    }

    private fun openImagePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "image/png"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(intent, pickImagesRequest)
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickImagesRequest || resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return

        val folder = File(filesDir, "cloud_frames").apply { mkdirs() }
        var copied = 0
        uris.forEachIndexed { index, uri ->
            try {
                val displayName = contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0) else null
                } ?: "cld_${System.currentTimeMillis()}_$index.png"
                val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")
                val target = File(folder, safeName)
                contentResolver.openInputStream(uri)?.use { input -> target.outputStream().use(input::copyTo) }
                if (target.length() > 0) copied++ else target.delete()
            } catch (_: Exception) { }
        }
        Toast.makeText(this, "$copied개 영상 가져오기 완료", Toast.LENGTH_LONG).show()
        refreshStatus()
    }

    private fun refreshStatus() {
        val folder = File(filesDir, "cloud_frames")
        val count = folder.listFiles { f -> f.isFile && f.extension.equals("png", true) }?.size ?: 0
        status.text = "저장된 위성영상: ${count}장\n${if (count > 1) "연속 재생 준비 완료" else if (count == 1) "1장 저장됨 · 여러 장이면 구름 움직임 재생" else "아직 가져온 영상이 없습니다"}"
    }
}
